# ad_lab


For compiling all files :
```bash
make
```

To generate random file
```bash
make random
```

To clean up
```bash
make clean
```
